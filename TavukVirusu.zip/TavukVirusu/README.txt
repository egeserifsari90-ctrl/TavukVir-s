index.html dosyasını tarayıcıda açın. Başlat ve Durdur düğmeleriyle kontrol edin. Ses sentetik bir efekttir.
